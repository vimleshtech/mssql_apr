

use hrms
/*
DDL:
	-CREATE 
	-ALTER
	-DROP 
	-TRUNCATE 
ALTER   : TO MODIFY THE TABLE STRUTURE 


top  : return given no of rows
distinct : show unique rows 
into : create new table with data from existing table 

join : to merge two or more than two tables
    -at least one column must be  same in all tables
	There are following types of join
	i. inner join   : return common or matching rows
	ii. outer join / full outer join 
		a. left join
		b. right join 

  other types of join:
	-self join
	-cross join 
	
*/

select * from j_employee

--add new column in existing table 
alter table j_employee
add phone varchar(15)

update j_employee
set phone = '+91-22444444'
where eid =2

--remove existing column
alter table j_employee
drop column email 


sp_help j_employee

--alter table and modify the size
alter table j_employee
alter column phone varchar(100)


--drop table 
select * from emp_identity
drop table  emp_identity


--TRUNCATE  : remove all data but structure will remain same
select * from Country
truncate table country

--top 
select * from j_employee
select top 3  * from j_employee

select top 3  * from j_employee
order by eid desc

--distinct
select * from j_employee

select distinct * from j_employee
select country from j_employee
select distinct country from j_employee


--into 
select * from j_employee

select * into country_india from j_employee
where country ='india'


select * from country_india 


--inner join 
select * from J_employee
select * from j_salary

--alias 
select eid  as employee_id, name from J_employee

select e.eid,e.name,e.gender,e.phone,s.sal
from j_employee as e inner join j_salary as s 
	on e.eid = s.id 

