/*
Constraints & Integrity : is rules or regulations
						: is also known as properties of column		 
--------------------------------
There are following of constraints:
	Primary key		: -no duplicate
					  -not null
					  -physically sorted
									1 3  
	Foreign key    : is refreential column from one table to another table
			       : this will allow either null value or referential value 
				   Example:
						Emp:
								1  naman
								2  jatin
								
						Sal :
								eid  basic
								1   444							
								2   555
	Unique		: -no duplicate
				  -one null allow 
	Not null    : madatory field 
	Null		: optional field 
	Default     : store data automatically 
				
	Check		: allow from given list 

--------------------------
--------------------------
	Identity column : auto incrementer, generated column 
		
Index & its type : index is concept of pagination or storage (data will be stored in sorter order)
-----------------------
	Cluster index  : is physically sorted 
				   : primary key cluster index 
						
	Non-cluster index: is virtually sorted 
					  	
	Composite key  : it's unique key which is combination of two or more than two field/column


	
Type conversion function, and other **
		cast()     : change data type 
		convert()  : change data type and format 

Scalar : function which return single value is known as scaller function 
	 upper()
	 len()
	lower()
	
	
Minus/ except 
Intersect
View

*/

use hrms

create table c_employee
(
eid int primary key,
fname varchar(50) not null,
lname varchar(40) null,
email  varchar(100) unique,
gender varchar(10) check (gender in ('male','female')),
create_date  datetime default getdate()
)

insert into c_employee(eid,fname,email,gender)
values(11,'Monika','monika@gmail.com','female')

select * from c_employee

--identity 
create table c_test
(
id int identity(1,1) , -- 1: start from , 1  increment by
name varchar(10)
)

insert into c_test 
values('test')

select * from c_test 


--non cluster index
create index i_test_index on c_employee
(fname)

create index i_test_index2 on c_employee
(fname,lname)

select * from c_employee where fname ='fff' and lname ='fff'

sp_help c_employee
--Type conversion function, and other **
select * from c_employee

select convert(varchar,eid)+fname , * from c_employee
select cast(eid as varchar)+fname , * from c_employee

--convert: we can change the format 
select getdate()  --yyy--mm-dd
select convert(varchar,getdate(),101) -- 101 to 113 inbuilt 
select convert(varchar,getdate(),102) -- 101 to 113
select convert(varchar,getdate(),103) -- 101 to 113
select convert(varchar,getdate(),104) -- 101 to 113
select convert(varchar,getdate(),105) -- 101 to 113
select convert(varchar,getdate(),106) -- 101 to 113


----Minus/ except  : table structure must be same 
select * into c_employee1 from c_employee 
--delete from c_employee1 where eid =11

select * from c_employee 
except
select * from c_employee1 


--or 
select * from c_employee  
where eid not in (select eid from c_employee1)

--Intersect : merge (show common rows ) 
--table structure should be same 
select * from c_employee 
intersect
select * from c_employee1 



-- View: is virtual table which can be used as a physical table
--view is also known as wrapper of over the table


--
select * from v_summary

drop view v_summary

sp_help c_employee 

alter table c_employee 
drop constraint PK__c_employ__D9509F6D1FF1BF5B
