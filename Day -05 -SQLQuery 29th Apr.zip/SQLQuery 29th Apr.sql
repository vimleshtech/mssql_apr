/*	
Recap:
	Type of server
	Auth Type
	Database Defination
	SQL Editions
	DDL	
		-create  : create new object (table, view, function etc.)
		-alter   : modify object's structure (table, view, function etc.)
		-drop    : drop object's (table, view, function etc.)
		-truncate  : truncate all data(rows) from table ,
						 but structure will remain same 
						-truncate doesn't where clause
					truncate table emp 
					truncate table emp  where eid =1  --this will not work 
	DML

		-insert    :
		-update    :
		-delete    : delete rows with conditin or condition 
					-delete allow where clause
						delete from emp where eid =1
						delete from emp 
							
	
	where 
	operator
			arithemtic:
				+ - * / %
			conditioal:
			>
			>=
			<
			<=
			=
			!=
			<>

		in
		not in
		between
		not between 

		logical
			and
			or

	order by 
		-asc
		-desc
	group by 
		-max()
		-min()
		-count()
		-sum()
		-avg()

	top			-return given no of rows from top 
	into		 -create new table from existing table 

	join :  
			-inner join    :  return common or matching rows 
								
			-full outer join  : return all rows 
			 -left join
			 -right 
			 
            -self join 
			-cross join 
	having

	union 

	subquery 
	
	function 
*/
select 1+2
select 11-2
select 11*2

use hrms
select * from j_employee
where eid > 2 and gender ='m'  --both condition should match


select *, 3*4 from j_employee


--inner join    :  return common or matching rows 
select * from j_employee 
select * from j_salary 

select e.eid, e.name, e.gender,s.sal 
from j_employee  as e inner join j_salary  s
	on e.eid = s.id 

								
-- full outer join  : return all rows (matching and non-matched)
select * from j_employee 
select * from j_salary 

select e.eid, e.name, e.gender,s.sal 
from j_employee  as e full outer join j_salary  s
	on e.eid = s.id 


-- left join : return all rows from left table and matching from right table
select e.eid, e.name, e.gender,s.sal 
from j_employee  as e left join j_salary  s
	on e.eid = s.id 


-- right join : return all rows from right table and matching from left 
select e.eid, e.name, e.gender,s.sal 
from j_employee  as e right join j_salary  s
	on e.eid = s.id 

			 
-- self join   : join with same table 
select * from j_employee
--output : eid name mgrname 
select e.eid,e.name,m.name as mgr_name
from j_employee as e left join j_employee as m
	on e.mgr_id = m.eid 

-- cross join  : is cartisan product 
-- A : 2 and B : 5 = 2*5 = 10
/*
A :
	1 a 
	2 b
B
	1 x
	2 y

  1 a  1 x
  1 a  2 y
  2 b   1 x
  2 b  2 y
*/  

select * 
from j_employee , j_salary

--cross join can be used as a inner join (however this is not recommended)
select * 
from j_employee , j_salary
where j_employee.eid  = j_salary.id 


---having   : filter the records after group by
--note: having can be used only with group by 
 
select gender, count(gender)
from j_employee
group by gender 

select gender, count(gender)
from j_employee
group by gender 
having count(gender) >3

1. from 
2. where
3. group by
4. having
5. order by 

--union  : to merge two or more than two tables (vertically)
-- table structure (column count, data type ) should be same in selection 
/*
There are following types of union:
i. union     : return distinct (unique rows)
ii. union all  : return all rows 

*/

select * into jemp_copy From j_employee

delete from j_employee where eid  =2
delete from jemp_copy where eid  >4

select * from j_employee
select * from jemp_copy

select * from j_employee
union 
select * from jemp_copy

select * from j_employee
union  all
select * from jemp_copy


-- subquery  : query inside query , first () will be solved 
--return 2nd highest id 
select * from j_employee

-- 2+3*4 =14
-- (2+3)*4 = 20

select top 1 * from 
					(select top 2 * from j_employee
					order by eid desc
					) temp   --temp is user defined name 
order by eid asc 

	
--- function : set of commands or intructions which can be reused
select getdate()
select datepart(yyyy,getdate())
select datepart(mm,getdate())
select datepart(day,getdate())
select datepart(QUARTER,getdate())
select datepart(DAYOFYEAR,getdate())

select datediff(yyyy,'1990-11-01',getdate())
select datediff(mm,'1990-11-01',getdate())
select datediff(day,'1990-11-01',getdate())
select datediff(HOUR,'1990-11-01',getdate()) as test



select max(eid) from j_employee

--text function 
select *, upper(name) from j_employee
select *, lower(name), len(name) from j_employee

select *, left(name,3), len(name) from j_employee
select *, right(name,3), len(name) from j_employee



