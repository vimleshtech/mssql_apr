/*
create database 
use database 
create - table
insert -data
view data 
update
delete row 

Topics:
---------------------------
Where Clause
Condtion 
Wildcard - like
order by - asc/desc
function - aggregiate function 
group by 
having
data type 
*/

/*
Where Clause : is conditional statement to filter the rows/records 
Condtional Operator:
		>
		>=
		<
		<=
		=
		!=		is not equal 
		<>		is not equal 
	Keywords:
		in
		not in
		between
		not between
		is equal 
		is not equal 			 
Logical Operator: to validate two or more than two conditions
	 and : condition is true if both will match/true 
	 or  : condition is false if anyone or both will match/true

*/
use hrms 
select * from j_employee

select * from j_employee where eid >2
select * from j_employee where eid >=2
select * from j_employee where eid <2
select * from j_employee where eid <=2
select * from j_employee where eid =2
select * from j_employee where name ='nitin'
select * from j_employee where eid <>2
select * from j_employee where eid !=2


select * from j_employee where eid in(1,5,6,7) --in list 
select * from j_employee where name in('nitin','jatin') --in list 
select * from j_employee where eid not  in(1,5,6,7)

select * from j_employee where eid between 2 and 4 --inclusive
select * from j_employee where eid not between 2 and 4 

select * from j_employee

select * from j_employee where mgr_id is null 
select * from j_employee where mgr_id is  not null 

--and
select * from j_employee 
where mgr_id is  not null  and eid >2 and gender ='f'

--or
select * from j_employee 
where mgr_id is  not null  or eid >2 

/*
Wildcard - like : pattern match 
 %	: any chars/digits and any length
 _  : any chars/digits with fix length

*/

select * from J_employee
where name like 'n%'   --start with n 

select * from J_employee
where name like '%n'   --end with n 


select * from J_employee
where name like '%n%'   --contains n 


select * from J_employee
where name like 'n____'


select * from J_employee
where email like 'n%@gamil.com'


select * from J_employee
where email like 'n%@%.%'

select * from J_employee
where email like '%@gamil.com' or email like '%@yahoo.com'

/* order by - asc/desc 
-arrange data in asc or desc order
-default is asc
*/

select * from j_employee
order by eid desc 


select * from j_employee
order by name 


select * from j_employee
order by 2 --by 2nd column

select * from j_employee
order by name asc, MGR_ID desc



select *		   --4
from j_employee    --1
where eid > 3      --2
order by name asc, MGR_ID desc --3

/*
function - aggregiate function 
max()
min()
sum()
avg()
count()
*/

select max(eid) from j_employee
select min(eid) from j_employee
select sum(eid) from j_employee
select avg(eid) from j_employee
select count(eid) from j_employee
select count(*) from j_employee
select count(mgr_id) from j_employee --exclude the null value 

/* 
group by  : summarize the data 
*/
select gender , count(gender)  --3
from j_employee  --1
group by gender  --2


select gender , count(gender) , max(eid), min(eid), avg(eid)
from j_employee  --1
group by gender  --2


/* having : is condition which can apply after/with group by */
select gender , count(gender)  --3
from j_employee  --1
group by gender  --2
having count(gender) >3


--seq
6. select   --view data /columns 
1. from    --source 
2. where    --filter  from raw data / source
3. group by  --sumarize 
4. having    --filter/condition  after group by 
5. order by  --arrange data in asc or desc 

/*
data type 
=======================
Numeric
	Number-without decimal
		tinyint      2 byte  
		int			 4 byte - 32 bit
		bigint		 8 byte - 64 byte 

	Number-with decimal
		float		4  byte   4444.333 (till 7 decimal)
		double      8 byte    444.433333 (till 15 decimal)
		numeric(5,2)    = 123.45 
Alpha Numeric (any key from keyboard) : 'data'
	char		: ASCII(english)		-fix size 
							char(3) = 'a',rest 2 chars will not be free
	nchar		: Unicode 

	varchar		: ASCII(english)		-dynamic size
						varchar(40) = 'ab' , rest 38 chars will be released
	nvarchar	: Unicode

	text		: ASCII(english)      -file , delimeted data 
								<id> 3433 </id>
	ntext		: Unicode

	Note : n  - unicode (multi language)

Boolean
	bit		: true(1)  / false (0)

Date
	date		: yyyy-mm-dd
	datetime    : yyyy-mm-dd hh:mm:ss
	smalldatetime    : yyyy-mm-dd hh:mm:ss.mis


other:
	varbinary : hexacode
				1001111ab0011111211

*/

create table sales
(
id int,
fname varchar(10),
lanem varchar(10),
gender char(1),
country varchar(30),
dob   date,
status  bit,
salary float
)


insert into sales
values(1,'nitin','sinha','m','india','1990-01-01',1,44401.55)

select * from sales 

/*
Next :
---------------------------
alter
drop 
trunate 
identity
top
into 
case when 
union 
join 
constriants 
*/
